import { useEffect, useState } from "react";
import { X, FileText, BookOpen, Brain } from "lucide-react";
import { supabase } from "../supabaseClient";
import Flashcards from "./Flashcards";

export default function MyLibrary({ session, onClose, onOpenDeck }) {
  const [loading, setLoading] = useState(true);
  const [documents, setDocuments] = useState([]);
  const [decks, setDecks] = useState([]);
  const [attempts, setAttempts] = useState([]);
  const [viewingDeck, setViewingDeck] = useState(null);
  const [viewingAttempt, setViewingAttempt] = useState(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [docsRes, decksRes, attemptsRes] = await Promise.all([
        supabase.from("documents").select("*").order("uploaded_at", { ascending: false }),
        supabase.from("flashcard_decks").select("*").order("created_at", { ascending: false }),
        supabase.from("quiz_attempts").select("*").order("created_at", { ascending: false }),
      ]);
      setDocuments(docsRes.data || []);
      setDecks(decksRes.data || []);
      setAttempts(attemptsRes.data || []);
      setLoading(false);
    }
    if (session) load();
  }, [session]);

  function itemsForDocument(documentId) {
    return {
      decks: decks.filter((d) => d.document_id === documentId),
      attempts: attempts.filter((a) => a.document_id === documentId),
    };
  }

  const unfiled = itemsForDocument(null);
  const groups = [
    ...documents.map((doc) => ({ doc, ...itemsForDocument(doc.id) })),
    ...(unfiled.decks.length || unfiled.attempts.length ? [{ doc: null, ...unfiled }] : []),
  ];

  if (viewingDeck) {
    return (
      <main className="feature-page">
        <button type="button" className="secondary" onClick={() => setViewingDeck(null)}>
          ← Back to Library
        </button>
        <section className="result-stage">
          <Flashcards
            cards={viewingDeck.cards}
            moduleName={viewingDeck.module_name}
            onGenerateNew={() => {}}
            onGenerateMore={() => {}}
            loadingMore={false}
            endMessage=""
            onSaveDeck={() => {}}
            saveStatus=""
          />
        </section>
      </main>
    );
  }

  if (viewingAttempt) {
    const questions = viewingAttempt.questions || [];
    return (
      <main className="feature-page">
        <button type="button" className="secondary" onClick={() => setViewingAttempt(null)}>
          ← Back to Library
        </button>
        <div className="feature-page-header">
          <h3 className="feature-page-title">{viewingAttempt.module_name}</h3>
          <p className="feature-page-copy">
            Score: {viewingAttempt.score} / {viewingAttempt.total_questions}
          </p>
        </div>
        <section className="result-stage result-stage-wide">
          {questions.map((q, i) => (
            <div key={i} className="quiz-card" style={{ marginBottom: "1rem" }}>
              <p className="quiz-question">{i + 1}. {q.question}</p>
              {q.correctAnswer && <p className="quiz-feedback-answer">Answer: {q.correctAnswer}</p>}
              {q.options && q.correctIndex !== undefined && (
                <p className="quiz-feedback-answer">Answer: {q.options[q.correctIndex]}</p>
              )}
              {q.explanation && <p className="quiz-feedback-explanation">💡 {q.explanation}</p>}
            </div>
          ))}
        </section>
      </main>
    );
  }

  return (
    <main className="feature-page">
      <header className="feature-page-header">
        <div>
          <span className="setup-label">library_page</span>
          <h3 className="feature-page-title">My Library</h3>
          <p className="feature-page-copy">Your saved flashcard decks and quiz attempts, grouped by source.</p>
        </div>
        <button type="button" className="secondary" onClick={onClose} aria-label="Close library">
          <X size={20} />
        </button>
      </header>

      {loading && <p className="mono text-center mt-6">Loading...</p>}

      {!loading && groups.length === 0 && (
        <p className="mono text-center mt-6">Nothing saved yet. Save a deck or quiz result to see it here.</p>
      )}

      {!loading &&
        groups.map((group, gi) => (
          <div key={group.doc?.id || "unfiled"} className="study-input-panel" style={{ marginTop: gi === 0 ? "1.5rem" : "1rem" }}>
            <div className="flex items-center gap-2 mb-3">
              <FileText size={16} />
              <span className="setup-label">
                {group.doc ? group.doc.filename : "Unfiled (no source document)"}
              </span>
            </div>

            {group.decks.map((deck) => (
              <button
                key={deck.id}
                type="button"
                className="secondary"
                style={{ display: "flex", alignItems: "center", gap: "0.5rem", width: "100%", marginBottom: "0.5rem" }}
                onClick={() => setViewingDeck(deck)}
              >
                <BookOpen size={16} /> {deck.module_name} — {deck.cards?.length || 0} cards
              </button>
            ))}

            {group.attempts.map((attempt) => (
              <button
                key={attempt.id}
                type="button"
                className="secondary"
                style={{ display: "flex", alignItems: "center", gap: "0.5rem", width: "100%", marginBottom: "0.5rem" }}
                onClick={() => setViewingAttempt(attempt)}
              >
                <Brain size={16} /> {attempt.module_name} — {attempt.score}/{attempt.total_questions}
              </button>
            ))}
          </div>
        ))}
    </main>
  );
}